//
//  MemeStruct.swift
//  MEME
//
//  Created by Me on 8/28/16.
//  Copyright © 2016 Me. All rights reserved.
//

import Foundation
import UIKit
struct MemeStruct {
    let top:String
    
    let bottom:String
    
    let Image:UIImage
    
    let memeImage:UIImage
}